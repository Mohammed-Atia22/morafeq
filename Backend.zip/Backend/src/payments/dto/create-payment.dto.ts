export class CreatePaymentDto {}
