export class Prisma {}
