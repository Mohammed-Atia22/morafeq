export class Message {}
