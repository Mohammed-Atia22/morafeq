export class CreateMessageDto {}
