export class CreateListingDto {}
