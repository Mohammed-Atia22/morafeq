export class Booking {}
