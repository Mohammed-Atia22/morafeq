export class CreateBookingDto {}
